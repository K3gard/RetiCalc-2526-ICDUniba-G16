/*
 ============================================================================
 Name        : TCP_Server.c
 Author      :
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define PORT 80
#define QLEN 5


void ErrorHandler(char *errorMessage)
{
	printf("%s", errorMessage);
}

void ClearWinSock()
{
#if defined WIN32
	WSACleanup();
#endif
}

int isVowel(char c)
{
	return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');
}

void removeVowels(char *str)
{
	int i, j = 0;
	for (i = 0; str[i] != '\0'; i++)
	{
		if (!isVowel(str[i]))
		{
			str[j++] = str[i];
		}
	}
	str[j] = '\0';
}

int main()
{
#if defined WIN32
	WSADATA wsaData;
	int iResult =
			WSAStartup(MAKEWORD(2, 2),
								 &wsaData);
	if (iResult != 0)
	{
		printf("Error at WSAStartup()\n");
		return -1;
	}
#endif

	// creazione socket server
	int MySocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (MySocket < 0)
	{
		ErrorHandler("socket creation failed.\n");
		ClearWinSock();
		return -1;
	}

	// assegnazione ip socket
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));
	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr("127.0.0.1");
	sad.sin_port = htons(PORT);
	if (bind(MySocket, (struct sockaddr *)&sad, sizeof(sad)) < 0)
	{
		ErrorHandler("bind() failed.\n");
		closesocket(MySocket);
		ClearWinSock();
		return -1;
	}

	// settaggio in ascolto della socket
	if (listen(MySocket, QLEN) < 0)
	{
		ErrorHandler("listen() failed.\n");
		closesocket(MySocket);
		ClearWinSock();
		return -1;
	}

	// accettazione connessione
	struct sockaddr_in cad; // struttura per socket temp
	int clientSocket;				// descrittore socket temp
	int clientLen;					// dim socket temp
	printf("Waiting for a client to connect...\n");
	while (1)
	{
		clientLen = sizeof(cad); // setta la dimensione della socket temp
		if ((clientSocket = accept(MySocket, (struct sockaddr *)&cad,
															 &clientLen)) < 0)
		{
			ErrorHandler("accept() failed.\n");
			// chiusura connessione
			closesocket(MySocket);
			ClearWinSock();
			return 0;
		}

		printf("ricevuti dati dal client con indirizzo: %s\n",
					 inet_ntoa(cad.sin_addr));

		char buffer[512];
		int bytesReceived;

		// 1
		bytesReceived = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
		if (bytesReceived <= 0)
		{
			ErrorHandler("accept() failed.\n");
			closesocket(clientSocket);
			return 0;
		}
		buffer[bytesReceived] = '\0';

		// 2
		bytesReceived = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
		if (bytesReceived <= 0)
		{
			ErrorHandler("accept() failed.\n");
			closesocket(clientSocket);
			return 0;
		}

		buffer[bytesReceived] = '\0';

		printf("Stringa ricevuta: %s\n", buffer);

		// 3
		removeVowels(buffer);

		// 4
		send(clientSocket, buffer, strlen(buffer), 0);

		// 5
		closesocket(clientSocket);
	}

// chiusura connessione socket benvenuto
closesocket(MySocket);
ClearWinSock();
return 0;
}
