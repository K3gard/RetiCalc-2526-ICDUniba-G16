/*
 ============================================================================
 Name        : server-UDP_G16.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <stdio.h>
#include <string.h>
#define BUFSIZE 255
#define PORT 48000

void ErrorHandler(const char *msg) {
    printf("%s\n", msg);
}

int isVowel(char c) {
    return (c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||
            c=='A'||c=='E'||c=='I'||c=='O'||c=='U');
}

void removeVowels(char *str) {
    int i, j = 0;
    for (i = 0; str[i] != '\0'; i++) {
        if (!isVowel(str[i])) {
            str[j++] = str[i];
        }
    }
    str[j] = '\0';
}

void ClearWinSock() {
#if defined WIN32
WSACleanup();
#endif
}

int main() {
#if defined WIN32
WSADATA wsaData;
int iResult = WSAStartup(MAKEWORD(2 ,2), &wsaData);
if (iResult != 0) {
printf ("error at WSASturtup\n");
return EXIT_FAILURE;
}
#endif
int sock;
struct sockaddr_in servAddr;
struct sockaddr_in clntAddr;
// creazione socket
if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
{
    ErrorHandler("socket() failed\n");
    return -1;
}
//assegnazione ip
memset(&servAddr, 0, sizeof(servAddr));
servAddr.sin_family = AF_INET;
servAddr.sin_port = htons(PORT);
servAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
if ((bind(sock, (struct sockaddr *)&servAddr, sizeof(servAddr))) < 0)
{
    ErrorHandler("bind() failed\n");
    return -1;
}
    while (1) {

        int clntLen = sizeof(clntAddr);
        char buffer[BUFSIZE];
        //1
        int recvSize = recvfrom(sock, buffer, BUFSIZE - 1, 0, (struct sockaddr *)&clntAddr, &clntLen);

        //risoluzione dns
        struct hostent *host = gethostbyaddr((char *)&clntAddr.sin_addr, sizeof(clntAddr.sin_addr), AF_INET);

        char *clientName = (host != NULL) ? host->h_name : "UNKNOWN";


        printf("Ricevuti dati dal client nome: %s indirizzo: %s\n", clientName, inet_ntoa(clntAddr.sin_addr));


        //2
        memset(buffer, 0, BUFSIZE);
        recvSize = recvfrom(sock, buffer, BUFSIZE - 1, 0, (struct sockaddr *)&clntAddr, &clntLen);

        printf("Stringa ricevuta: %s\n", buffer);

        //3
        removeVowels(buffer);

        //4
        sendto(sock, buffer, strlen(buffer), 0, (struct sockaddr *)&clntAddr, clntLen);
    }

#if defined WIN32
    WSACleanup();
#endif

    return 0;
}
