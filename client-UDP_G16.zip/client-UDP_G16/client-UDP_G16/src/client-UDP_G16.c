/*
 ============================================================================
 Name        : client-UDP_G16.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ECHOMAX 255

void ErrorHandler(char *errorMessage) {
    printf("%s\n", errorMessage);
}

void ClearWinSock() {
#if defined WIN32
    WSACleanup();
#endif
}

int main() {

#if defined WIN32
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2 ,2), &wsaData) != 0) {
        printf("Error at WSAStartup\n");
        return EXIT_FAILURE;
    }
#endif

    int sock;
    struct sockaddr_in servAddr;
    struct sockaddr_in fromAddr;
    int fromSize;

    char buffer[ECHOMAX];
    char serverName[100];
    int port;

    //nome e porta
    printf("Inserisci nome host del server: ");
    scanf("%s", serverName);

    printf("Inserisci porta del server: ");
    scanf("%d", &port);

    //dns
    struct hostent *host = gethostbyname(serverName);
    if (host == NULL) {
        ErrorHandler("gethostbyname() failed");
        return EXIT_FAILURE;
    }

    //creazione socket
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        ErrorHandler("socket() failed");
        return EXIT_FAILURE;
    }

    //asegnazione ip
    memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = PF_INET;
    servAddr.sin_port = htons(port);
    memcpy(&servAddr.sin_addr, host->h_addr, host->h_length);

    //1
    strcpy(buffer, "Hello");
    sendto(sock, buffer, strlen(buffer), 0, (struct sockaddr *)&servAddr, sizeof(servAddr));

    //2
    memset(buffer, 0, ECHOMAX);
    printf("Inserisci stringa da inviare: ");
    getchar();
    scanf("%254[^\n]", buffer);  // legge tutto fino a '\n'
    getchar();
    sendto(sock, buffer, strlen(buffer), 0, (struct sockaddr *)&servAddr, sizeof(servAddr));

    //3
    memset(buffer, 0, ECHOMAX);
    fromSize = sizeof(fromAddr);
    int recvLen = recvfrom(sock, buffer, ECHOMAX - 1, 0, (struct sockaddr *)&fromAddr, &fromSize);
    if (recvLen < 0) {
        ErrorHandler("recvfrom() failed");
        return EXIT_FAILURE;
    }

    //4
    struct hostent *srvHost =
        gethostbyaddr((char *)&fromAddr.sin_addr, sizeof(fromAddr.sin_addr), PF_INET);

    char *srvName = (srvHost != NULL) ? srvHost->h_name : "UNKNOWN";

    printf("Stringa %s ricevuta dal server nome:%s indirizzo:%s\n",buffer,srvName,inet_ntoa(fromAddr.sin_addr));

    //chisura socket
    closesocket(sock);
    ClearWinSock();
    return EXIT_SUCCESS;
}
